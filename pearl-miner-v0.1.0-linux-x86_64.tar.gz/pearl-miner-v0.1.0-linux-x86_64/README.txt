Pearl Miner — Linux x86_64

Requirements:
  - NVIDIA GPU (GTX 16xx, RTX 20xx/30xx/40xx/50xx)
  - NVIDIA driver >= 525 (CUDA 12.0+)
  - glibc >= 2.31

Usage:
  ./pearl-miner --wallet <WALLET> --pool <POOL> [--password <PASS>] [--gpu 0,1,...]

Examples:
  # All GPUs (default)
  ./pearl-miner --wallet prl1... --pool us1.alphapool.tech:5566

  # Specific GPUs
  ./pearl-miner --wallet prl1... --pool us1.alphapool.tech:5566 --gpu 0,1
